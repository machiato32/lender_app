# csocsort_app

Source code for the Lender App, which can be found on [Google Play](https://play.google.com/store/apps/details?id=csocsort.hu.machiato32.csocsort_szamla&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1).

Lender is an app designed for groups. You can easily track your expenses, loans and lendings towards your mates. The app does not use any personal data.
