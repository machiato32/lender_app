const String APPURL =  'http://csocsort.ddns.net/api';
String apiToken;
String currentUser;
String currentGroupName;
int currentGroupId;
