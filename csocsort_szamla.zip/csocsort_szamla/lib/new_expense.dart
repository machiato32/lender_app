import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';

class NewExpense extends StatefulWidget {
  @override
  _NewExpenseState createState() => _NewExpenseState();
}

class _NewExpenseState extends State<NewExpense> {
  TextEditingController amountController = TextEditingController();
  TextEditingController noteController = TextEditingController();
  Future<List<String>> names;
  Future<bool> success;
  bool waiting=false;
  Map<String,bool> checkboxBool = Map<String,bool>();

  Future<List<String>> getNames() async {
    http.Response response = await http.get('http://katkodominik.web.elte.hu/JSON/names');
    Map<String, dynamic> response2 = jsonDecode(response.body);

    List<String> list = response2['names'].cast<String>();
    list.remove(name);
    return list;

  }

  Future<bool> postNewExpense(List<String> names, int amount, String note) async{
    waiting=true;
    Map<String, dynamic> map = {
      "type":"new_expense",
      "from_name":name,
      "to_names":names,
      "amount":amount,
      "note":note
    };

    String encoded = json.encode(map);

    http.Response response = await http.post('http://katkodominik.web.elte.hu/JSON/', body: encoded);

    return response.statusCode==200;

  }

  @override
  void initState() {
    super.initState();
    names = getNames();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Vettem dolgokat')),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: (){
            FocusScope.of(context).unfocus();
          },
          child: Container(
            child: ListView(
              shrinkWrap: true,
              children: <Widget>[
                Text('Mennyiért vettél?'),
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 8,),
                Text('Mit vettél?'),
                TextField(
                  controller: noteController,
                ),
                SizedBox(height: 8,),
                Text('Kinek/kinknek vetted?'),
                Center(
                  child: FutureBuilder(
                    future: names,
                    builder: (context, snapshot){
                      if(snapshot.hasData){
                        for(String name in snapshot.data){
                          checkboxBool.putIfAbsent(name, () => false);
                        }
                        return ListView(
                          shrinkWrap: true,
                          children: snapshot.data.map<CheckboxListTile>((String name)=>
                            CheckboxListTile(
                                title: Text(name),
                                value: checkboxBool[name],
                                onChanged: (bool newValue){
                                  FocusScope.of(context).unfocus();
                                  setState(() {
                                    checkboxBool[name]=newValue;
                                  });
                                },
                              ),
                          ).toList(),
                        );
                      }
                      return CircularProgressIndicator();
                    },
                  ),
                ),
                SizedBox(height: 8,),
                FlatButton(
                  onPressed: (){
                    FocusScope.of(context).unfocus();
                    success=null;
                    int amount = int.parse(amountController.text);
                    String note = noteController.text;
                    List<String> names = new List<String>();
                    checkboxBool.forEach((String key, bool value) {
                      if(value) names.add(key);
                    });
                    success=postNewExpense(names, amount, note);
                    setState(() {

                    });
                  },
                  child: Text('Zsa',
                    style: TextStyle(
                      fontStyle: FontStyle.normal,
                      fontSize: 40,
                      color: Colors.lightBlue
                    ),
                  ),
                ),
                Center(
                  child: FutureBuilder(
                      future: success,
                      builder: (context, snapshot){
                        if(snapshot.hasData){
                          waiting=false;
                          if(snapshot.data){
                            return Icon(Icons.check, color: Colors.green, size: 30,);
                          }else{
                            return Icon(Icons.clear, color: Colors.red, size: 30,);
                          }
                        }
                        if(waiting){
                          return CircularProgressIndicator();
                        }
                        return SizedBox();
                      }

                  ),
                )
              ],

            ),

          ),
        ),
      ),
    );
  }
}
