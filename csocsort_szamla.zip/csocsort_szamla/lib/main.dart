import 'package:flutter/material.dart';
import 'payment.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'person.dart';
import 'new_expense.dart';
import 'sign_in.dart';
import 'change_pin.dart';


void main() => runApp(MyApp());

class SizeConfig {
  static MediaQueryData _mediaQueryData;
  static double screenWidth;
  static double screenHeight;
  static double blockSizeHorizontal;
  static double blockSizeVertical;

  void init(BuildContext context) {
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;
    blockSizeHorizontal = screenWidth / 100;
    blockSizeVertical = screenHeight / 100;
  }
}

String name;

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        accentColor: Colors.lightBlue,
        textTheme: TextTheme(
          title: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 30,
            color: Colors.blue
          ),
          body1: TextStyle(
            fontStyle: FontStyle.italic,
            fontSize: 25,
            color: Colors.lightBlue
          ),
          body2: TextStyle(
              fontStyle: FontStyle.normal,
              fontSize: 35,
              color: Colors.redAccent
          ),
        )
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Future<List<Person>> money;
  SharedPreferences prefs;
  Future<List<Person>> getMoney() async {
    http.Response response = await http.get('http://katkodominik.web.elte.hu/JSON/');
    List<dynamic> list = jsonDecode(response.body);
    List<Person> people = List<Person>();
    for(var element in list){
      people.add(Person.fromJson(element));
    }
    return people;
  }

  Future<SharedPreferences> getPrefs() async{
    return await SharedPreferences.getInstance();
  }

  @override
  void initState() {
    super.initState();
    getPrefs().then((_prefs){
      if(!_prefs.containsKey('name')){
        Navigator.push(context, MaterialPageRoute(builder: (context) => SignIn()));
      }else{
        name=_prefs.get('name');
      }
    });
    money = getMoney();
    name="Samu";
  }
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Csocsort befizetések'),
        actions: <Widget>[
          PopupMenuButton<String>(
            onSelected: (choice){
              if(choice=='Felhasználóváltás'){
                Navigator.push(context, MaterialPageRoute(builder: (context) => SignIn()));
              }else if(choice=='Jelszó megváltoztatása'){
                Navigator.push(context, MaterialPageRoute(builder: (context) => ChangePin()));
              }
            },
            itemBuilder: (BuildContext context){
              return ['Felhasználóváltás', 'Jelszó megváltoztatása'].map((String choice){
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            },
          )
        ],
      ),
      body: RefreshIndicator(
        onRefresh: (){
          return getMoney().then((_money) { setState(() {
            money=Future<List<Person>>.value(_money);
          });});
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: ListView(
              shrinkWrap: true,
              children: <Widget>[
                Align(child: Text('Szia $name!'), alignment: Alignment.topRight),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Text('Mizu?', style: Theme.of(context).textTheme.title,),
                    FlatButton(
                      child: Text('Vettem valamit', style: Theme.of(context).textTheme.body1),
                      onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => NewExpense()));},
                    ),
                    FlatButton(
                      child: Text('Fizettem valakinek', style: Theme.of(context).textTheme.body1,),
                      onPressed: ()  {Navigator.push(context, MaterialPageRoute(builder: (context) => Payment()));},
                    ),
                    Divider(),

                  ],
                ),
                Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Center(
                        child: Text('Egyenlegek', style: Theme.of(context).textTheme.title,),
                      ),
                      SizedBox(height: 40),
                      Center(
                        child: FutureBuilder(
                          future: money,
                          builder: (context, snapshot){
                            if(snapshot.hasData){
                              return ListView.builder(
                                shrinkWrap: true,
                                itemCount: snapshot.data.length,
                                itemBuilder: (BuildContext context, int index){
                                  return Text(snapshot.data[index].name+' '+snapshot.data[index].amount.toString());
                                },
                              );
                            }
                            return CircularProgressIndicator();
                          },
                        ),
                      )
                    ],
                  ),
              ],
            ),
          ),
        ),
      ),

    );
  }
}
