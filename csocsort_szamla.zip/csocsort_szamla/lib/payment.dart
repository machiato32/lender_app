import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';
class Payment extends StatefulWidget {
  @override
  _PaymentState createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  Future<List<String>> names;
  Future<bool> success;
  bool waiting=false;
  String dropdownValue;
  TextEditingController amountController = TextEditingController();
  TextEditingController noteController = TextEditingController();

  Future<List<String>> getNames() async {
    http.Response response = await http.get('http://katkodominik.web.elte.hu/JSON/names');
    Map<String, dynamic> response2 = jsonDecode(response.body);

    List<String> list = response2['names'].cast<String>();
    list.remove(name);
    dropdownValue=list[0];
    return list;

  }

  Future<bool> postPayment(int amount, String note, String toName) async {
    waiting=true;
    Map<String,dynamic> map = {
      'type':'payment',
      'from_name':name,
      'to_name':toName,
      'amount':amount,
      'note':note
    };
    String encoded = json.encode(map);

    http.Response response = await http.post('http://katkodominik.web.elte.hu/JSON/', body: encoded);

    return response.statusCode==200;

  }

  @override
  void initState() {
    super.initState();

    names = getNames();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text('De hát én fizettem na'),),
      body:
        GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: (){
            FocusScope.of(context).unfocus();
          },
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Container(
              child: ListView(
                shrinkWrap: true,
                children: <Widget>[
                  Text('Neki fizettem:'),
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: FutureBuilder(
                          future: names,
                          builder: (context, snapshot) {
                            if(snapshot.hasData){
                              return DropdownButton(
                                value: dropdownValue,
                                onChanged: (String newValue) {
                                  setState(() {
                                    dropdownValue=newValue;
                                  });
                                },
                                items: snapshot.data.map<DropdownMenuItem<String>>((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value, style: Theme.of(context).textTheme.body2),
                                    );
                                }).toList(),

                              );
                            }

                            return CircularProgressIndicator();

                          },
                        ),
                    ),
                  ),
                  Text('Ennyit fizettem'),
                  TextField(
                    controller: amountController,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 8,),
                  Text('Megjegyzés rovat'),
                  TextField(
                    controller: noteController,
                  ),
                  Center(
                    child: FlatButton(
                      child: Text('Zsa',
                        style: TextStyle(
                          fontStyle: FontStyle.normal,
                          fontSize: 40,
                          color: Colors.lightBlue
                        ),
                      ),
                      onPressed: () {
                        FocusScope.of(context).unfocus();
                        success=null;
                        int amount = int.parse(amountController.text);
                        String note = noteController.text;
                        success=postPayment(amount, note, dropdownValue);
                        setState(() {

                        });
                      },
                    ),
                  ),
                  Center(
                    child: FutureBuilder(
                      future: success,
                      builder: (context, snapshot){
                        if(snapshot.hasData){
                          waiting=false;
                          if(snapshot.data){
                            return Icon(Icons.check, color: Colors.green, size: 30,);
                          }else{
                            return Icon(Icons.clear, color: Colors.red, size: 30,);
                          }
                        }
                        if(waiting){
                          return CircularProgressIndicator();
                        }
                        return SizedBox();
                      }

                    ),
                  )
                ],
              ),
            ),
          ),
        )

    );
  }
}
