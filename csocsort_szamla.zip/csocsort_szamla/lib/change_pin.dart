import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ChangePin extends StatefulWidget {
  @override
  _ChangePinState createState() => _ChangePinState();
}

class _ChangePinState extends State<ChangePin> {
  TextEditingController oldPin = TextEditingController();
  TextEditingController newPin = TextEditingController();
  TextEditingController confirmPin = TextEditingController();

  Future<bool> success;
  bool waiting=false;

  Future<bool> postNewPin(int oldPin, int newPin) async{
    waiting=true;
    Map<String,dynamic> map ={
      'type':'change',
      'name':name,
      'pin':oldPin,
      'new_pin':newPin
    };

    String encoded = jsonEncode(map);

    http.Response response = await http.post('http://katkodominik.web.elte.hu/JSON/validate/', body: encoded);

    Map<String,dynamic> decoded = jsonDecode(response.body);

    return (response.statusCode==200 && decoded['valid']);

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Meg akarom változtatni!'),),
      body: Padding(
        padding: EdgeInsets.all(8),
        child: Column(
          children: <Widget>[
            Text('Mi a mostani pined?'),
            TextField(
              controller: oldPin,
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            Text('Mi legyen az új pined?'),
            TextField(
              controller: newPin,
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            Text('Még egyszer?'),
            TextField(

              controller: confirmPin,
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            FlatButton(
              onPressed: (){
                FocusScope.of(context).unfocus();
                success=null;
                if(confirmPin.text==newPin.text){
                  success=postNewPin(int.parse(oldPin.text), int.parse(newPin.text));
                }else{
                  Fluttertoast.showToast(msg: 'Az új pin és az újrázás nem ugyanaz :(');
                }
                setState(() {

                });
              },
              child: Text('Zsa',
                style: TextStyle(
                    fontStyle: FontStyle.normal,
                    fontSize: 40,
                    color: Colors.lightBlue
                ),
              ),
            ),
            Center(
              child: FutureBuilder(
                  future: success,
                  builder: (context, snapshot){
                    if(snapshot.hasData){
                      waiting=false;
                      if(snapshot.data){
                        return Icon(Icons.check, color: Colors.green, size: 30,);
                      }else{
                        return Icon(Icons.clear, color: Colors.red, size: 30,);
                      }
                    }
                    if(waiting){
                      return CircularProgressIndicator();
                    }
                    return SizedBox();
                  }
              ),
            )
          ],
        ),
      ),

    );
  }
}
