import 'package:admob_flutter/admob_flutter.dart';
import 'package:flutter/material.dart';
import 'package:csocsort_szamla/config.dart';

Map<String, String> appUnitIds = {
  'create_group':'ca-app-pub-9930178408864309/4416104571',
  'history':'ca-app-pub-9930178408864309/1789941235',
  'home_screen':'ca-app-pub-9930178408864309/5502719874',
  'join_group':'ca-app-pub-9930178408864309/2911451218',
  'payment':'ca-app-pub-9930178408864309/6659124536',
  'purchase':'ca-app-pub-9930178408864309/2719879526',
  'report_bug':'ca-app-pub-9930178408864309/5154471176',
  'settings':'ca-app-pub-9930178408864309/1215226163'
};

Widget adUnitForSite(String site, {AdmobBannerSize size = AdmobBannerSize.BANNER}){
  return Visibility(
    visible: showAds,
    child: AdmobBanner(
      adUnitId: appUnitIds[site],
      adSize: size,
      nonPersonalizedAds: !personalisedAds,
    ),
  );
}