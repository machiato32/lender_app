// The url_launcher_platform_interface defaults to MethodChannelUrlLauncher
// as its instance, which is all the Linux implementation needs. This file
// is here to silence warnings when publishing to pub.
