## 2.0.0

* Migrate to null-safety.

## 0.0.3+1

* Update Flutter SDK constraint.

## 0.0.3

* Update integration test examples to use `testWidgets` instead of `test`.

## 0.0.2+4

* Remove unused `test` dependency.
* Update Dart SDK constraint in example.

## 0.0.2+3

* Check in linux/ directory for example/

## 0.0.2+2

* Bump the `file` package dependency to resolve dep conflicts with `flutter_driver`.

## 0.0.2+1
* Replace path_provider dependency with path_provider_linux.

## 0.0.2
* Add iOS stub.

## 0.0.1
* Initial release to support shared_preferences on Linux.
