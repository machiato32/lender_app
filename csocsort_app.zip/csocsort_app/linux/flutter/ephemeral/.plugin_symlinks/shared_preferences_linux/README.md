# shared_preferences_linux

The Linux implementation of [`shared_preferences`][1].

## Usage

### Import the package

This package is an unendorsed Linux implementation of `shared_preferences`.

In order to use this now, you'll need to depend on `shared_preferences_linux`.
When this package is endorsed it will be automatically used by the `shared_preferences` package and you can switch to that API.

```yaml
...
dependencies:
  ...
  shared_preferences_linux: ^0.0.1
  ...
```

[1]: ../
