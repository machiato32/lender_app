package csocsort.hu.machiato32.csocsort_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
