# Lender APP
###### money and debt management app for groups

Source code for the Lender App, which can be found on [Google Play](https://play.google.com/store/apps/details?id=csocsort.hu.machiato32.csocsort_szamla) and on the [App Store](https://apps.apple.com/us/app/lender-finances-for-groups/id1558223634).

Lender is an app designed for groups. You can easily track your expenses, loans and lendings towards your mates.
